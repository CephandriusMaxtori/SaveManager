package com.choculaterie.widget;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import org.lwjgl.glfw.GLFW;

public class CustomTextField extends class_342 {
    private static final int FIELD_BG_COLOR = 0xFF2A2A2A;
    private static final int FIELD_BORDER_COLOR = 0xFF555555;
    private static final int FIELD_BORDER_FOCUSED_COLOR = 0xFF888888;
    private static final int CLEAR_BUTTON_SIZE = 12;
    private static final long INITIAL_DELAY = 400;
    private static final long REPEAT_DELAY = 50;

    private final class_310 client;
    private Runnable onEnterPressed;
    private Runnable onChanged;
    private Runnable onClearPressed;
    private boolean wasEnterDown = false;
    private boolean wasClearButtonMouseDown = false;
    private class_2561 placeholderText;

    private static CustomTextField activeField = null;
    private static boolean callbackInstalled = false;
    private static long installedWindowHandle = 0;

    private final KeyRepeatTracker backspace = new KeyRepeatTracker();
    private final KeyRepeatTracker delete = new KeyRepeatTracker();
    private final KeyRepeatTracker left = new KeyRepeatTracker();
    private final KeyRepeatTracker right = new KeyRepeatTracker();
    private boolean wasHomePressed = false;
    private boolean wasEndPressed = false;
    private boolean wasCtrlCPressed = false;
    private boolean wasCtrlVPressed = false;

    public CustomTextField(class_310 client, int x, int y, int width, int height, class_2561 text) {
        super(client.field_1772, x, y, width, height, text);
        this.client = client;
        this.method_1880(256);
        this.method_1858(false);
        this.method_1856(true);
    }

    @Override
    public void method_1867(String text) {}

    public void setOnEnterPressed(Runnable callback) { this.onEnterPressed = callback; }
    public void setOnChanged(Runnable callback) { this.onChanged = callback; }
    public void setOnClearPressed(Runnable callback) { this.onClearPressed = callback; }

    @Override
    public void method_25365(boolean focused) {
        super.method_25365(focused);
        if (focused) {
            activeField = this;
            installCharCallback();
        } else if (activeField == this) {
            activeField = null;
        }
    }

    private void installCharCallback() {
        long wh = getWindowHandle();
        if (wh != 0 && (!callbackInstalled || installedWindowHandle != wh)) {
            GLFW.glfwSetCharCallback(wh, (window, codepoint) -> {
                if (activeField != null && activeField.method_25370()) {
                    activeField.onCharTyped((char) codepoint);
                }
            });
            callbackInstalled = true;
            installedWindowHandle = wh;
        }
    }

    private void onCharTyped(char c) {
        if (c == '\r' || c == '\n' || c < 32) return;
        String text = this.method_1882();
        int cursor = this.method_1881();
        if (text.length() < 256) {
            this.method_1852(text.substring(0, cursor) + c + text.substring(cursor));
            this.method_1883(cursor + 1, false);
            fireChanged();
        }
    }

    @Override
    public void method_47404(class_2561 placeholder) {
        super.method_47404(placeholder);
        this.placeholderText = placeholder;
    }

    private boolean isOverClearButton(int mouseX, int mouseY) {
        if (this.method_1882().isEmpty()) return false;
        int clearX = this.method_46426() + this.method_25368() - CLEAR_BUTTON_SIZE - 4;
        int clearY = this.method_46427() + (this.method_25364() - CLEAR_BUTTON_SIZE) / 2 + 1;
        return mouseX >= clearX && mouseX < clearX + CLEAR_BUTTON_SIZE &&
                mouseY >= clearY && mouseY < clearY + CLEAR_BUTTON_SIZE;
    }

    @Override
    public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        long wh = getWindowHandle();

        if (wh != 0) {
            handleClearButton(wh, mouseX, mouseY);
            handleEnterKey(wh);
        } else {
            wasClearButtonMouseDown = false;
        }

        if (wh != 0 && this.method_25370()) handleSpecialKeys(wh);

        renderBackground(context);
        renderText(context, mouseX, mouseY);
    }

    private void handleClearButton(long wh, int mouseX, int mouseY) {
        boolean isMouseDown = GLFW.glfwGetMouseButton(wh, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (!this.method_1882().isEmpty() && isMouseDown && !wasClearButtonMouseDown && isOverClearButton(mouseX, mouseY)) {
            this.method_1852("");
            fireChanged();
            if (onClearPressed != null) onClearPressed.run();
        }
        wasClearButtonMouseDown = isMouseDown;
    }

    private void handleEnterKey(long wh) {
        boolean isEnterDown = GLFW.glfwGetKey(wh, GLFW.GLFW_KEY_ENTER) == GLFW.GLFW_PRESS ||
                GLFW.glfwGetKey(wh, GLFW.GLFW_KEY_KP_ENTER) == GLFW.GLFW_PRESS;
        if (this.method_25370() && onEnterPressed != null && isEnterDown && !wasEnterDown) {
            onEnterPressed.run();
        }
        wasEnterDown = isEnterDown;
    }

    private void renderBackground(class_332 context) {
        int x = this.method_46426(), y = this.method_46427(), w = this.method_25368(), h = this.method_25364();
        context.method_25294(x, y, x + w, y + h, FIELD_BG_COLOR);
        int bc = this.method_25370() ? FIELD_BORDER_FOCUSED_COLOR : FIELD_BORDER_COLOR;
        context.method_25294(x, y, x + w, y + 1, bc);
        context.method_25294(x, y + h - 1, x + w, y + h, bc);
        context.method_25294(x, y, x + 1, y + h, bc);
        context.method_25294(x + w - 1, y, x + w, y + h, bc);
    }

    private void renderText(class_332 context, int mouseX, int mouseY) {
        int textY = this.method_46427() + (this.method_25364() - 8) / 2;
        int textX = this.method_46426() + 4;
        int maxTextWidth = this.method_25368() - 8 - (this.method_1882().isEmpty() ? 0 : CLEAR_BUTTON_SIZE + 4);
        String text = this.method_1882();

        if (text.isEmpty() && !this.method_25370()) {
            if (placeholderText != null) {
                context.method_27535(client.field_1772, placeholderText, textX, textY, 0xFF888888);
            }
        } else {
            int color = this.method_25370() ? 0xFFFFFFFF : 0xFFE0E0E0;
            int cursor = this.method_1881();
            context.method_44379(textX, this.method_46427(), textX + maxTextWidth, this.method_46427() + this.method_25364());
            context.method_25303(client.field_1772, text, textX, textY, color);
            context.method_44380();
            if (this.method_25370() && this.method_20315() && (System.currentTimeMillis() / 500) % 2 == 0) {
                int cursorX = textX + client.field_1772.method_1727(text.substring(0, Math.min(cursor, text.length())));
                context.method_25294(cursorX, textY - 1, cursorX + 1, textY + 9, 0xFFFFFFFF);
            }
        }

        if (!text.isEmpty()) {
            int clearX = this.method_46426() + this.method_25368() - CLEAR_BUTTON_SIZE - 4;
            int clearY = this.method_46427() + (this.method_25364() - CLEAR_BUTTON_SIZE) / 2 + 1;
            boolean isHovered = isOverClearButton(mouseX, mouseY);
            String xSymbol = "\u2715";
            int xWidth = client.field_1772.method_1727(xSymbol);
            context.method_25303(client.field_1772, xSymbol,
                    clearX + (CLEAR_BUTTON_SIZE - xWidth) / 2,
                    clearY + (CLEAR_BUTTON_SIZE - 8) / 2,
                    isHovered ? 0xFFAAAAAA : 0xFF888888);
        }
    }

    private void handleSpecialKeys(long wh) {
        long now = System.currentTimeMillis();
        String text = this.method_1882();
        int cursor = this.method_1881();

        if (backspace.shouldFire(GLFW.glfwGetKey(wh, GLFW.GLFW_KEY_BACKSPACE) == GLFW.GLFW_PRESS, now, INITIAL_DELAY, REPEAT_DELAY)) {
            if (cursor > 0) {
                this.method_1852(text.substring(0, cursor - 1) + text.substring(cursor));
                this.method_1883(cursor - 1, false);
                text = this.method_1882();
                cursor = this.method_1881();
                fireChanged();
            }
        }

        if (delete.shouldFire(GLFW.glfwGetKey(wh, GLFW.GLFW_KEY_DELETE) == GLFW.GLFW_PRESS, now, INITIAL_DELAY, REPEAT_DELAY)) {
            if (cursor < text.length()) {
                this.method_1852(text.substring(0, cursor) + text.substring(cursor + 1));
                text = this.method_1882();
                fireChanged();
            }
        }

        if (left.shouldFire(GLFW.glfwGetKey(wh, GLFW.GLFW_KEY_LEFT) == GLFW.GLFW_PRESS, now, INITIAL_DELAY, REPEAT_DELAY)) {
            if (cursor > 0) this.method_1883(cursor - 1, false);
        }

        if (right.shouldFire(GLFW.glfwGetKey(wh, GLFW.GLFW_KEY_RIGHT) == GLFW.GLFW_PRESS, now, INITIAL_DELAY, REPEAT_DELAY)) {
            if (cursor < text.length()) this.method_1883(cursor + 1, false);
        }

        boolean isHomeDown = GLFW.glfwGetKey(wh, GLFW.GLFW_KEY_HOME) == GLFW.GLFW_PRESS;
        if (isHomeDown && !wasHomePressed) this.method_1883(0, false);
        wasHomePressed = isHomeDown;

        boolean isEndDown = GLFW.glfwGetKey(wh, GLFW.GLFW_KEY_END) == GLFW.GLFW_PRESS;
        if (isEndDown && !wasEndPressed) this.method_1883(text.length(), false);
        wasEndPressed = isEndDown;

        if (GLFW.glfwGetKey(wh, GLFW.GLFW_KEY_ESCAPE) == GLFW.GLFW_PRESS) this.method_25365(false);

        boolean isCtrlDown = GLFW.glfwGetKey(wh, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS ||
                GLFW.glfwGetKey(wh, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS;

        boolean isCtrlCDown = isCtrlDown && GLFW.glfwGetKey(wh, GLFW.GLFW_KEY_C) == GLFW.GLFW_PRESS;
        if (isCtrlCDown && !wasCtrlCPressed && !text.isEmpty()) {
            GLFW.glfwSetClipboardString(wh, text);
        }
        wasCtrlCPressed = isCtrlCDown;

        boolean isCtrlVDown = isCtrlDown && GLFW.glfwGetKey(wh, GLFW.GLFW_KEY_V) == GLFW.GLFW_PRESS;
        if (isCtrlVDown && !wasCtrlVPressed) {
            String clip = GLFW.glfwGetClipboardString(wh);
            if (clip != null && !clip.isEmpty()) {
                String sanitized = clip.replaceAll("[\\r\\n]+", "");
                if (!sanitized.isEmpty()) {
                    String newText = text.substring(0, cursor) + sanitized + text.substring(cursor);
                    if (newText.length() <= 256) {
                        this.method_1852(newText);
                        this.method_1883(cursor + sanitized.length(), false);
                        fireChanged();
                    }
                }
            }
        }
        wasCtrlVPressed = isCtrlVDown;
    }

    private void fireChanged() {
        if (onChanged != null) onChanged.run();
    }

    private long getWindowHandle() {
        return client.method_22683() != null ? client.method_22683().method_4490() : 0;
    }

    private static class KeyRepeatTracker {
        private boolean wasDown;
        private long holdStart;
        private long lastRepeat;

        boolean shouldFire(boolean isDown, long now, long initialDelay, long repeatDelay) {
            if (isDown) {
                if (!wasDown) {
                    wasDown = true;
                    holdStart = now;
                    lastRepeat = now;
                    return true;
                } else if (now - holdStart > initialDelay && now - lastRepeat > repeatDelay) {
                    lastRepeat = now;
                    return true;
                }
            } else {
                wasDown = false;
            }
            return false;
        }
    }
}
