package com.choculaterie.widget;

import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;

public class CustomButton extends class_4185 {
    private static final int BUTTON_COLOR = 0xFF3A3A3A;
    private static final int BUTTON_HOVER_COLOR = 0xFF4A4A4A;
    private static final int BUTTON_DISABLED_COLOR = 0xFF2A2A2A;
    private static final int TEXT_COLOR = 0xFFFFFFFF;
    private static final int TEXT_DISABLED_COLOR = 0xFF888888;

    private boolean renderAsXIcon = false;
    private boolean renderAsDownloadIcon = false;
    private ToastManager toastManager = null;

    public CustomButton(int x, int y, int width, int height, net.minecraft.class_2561 message, class_4241 onPress) {
        super(x, y, width, height, message, onPress, field_40754);
    }

    public void setToastManager(ToastManager toastManager) {
        this.toastManager = toastManager;
    }

    public void setRenderAsXIcon(boolean renderAsXIcon) {
        this.renderAsXIcon = renderAsXIcon;
    }

    public void setRenderAsDownloadIcon(boolean renderAsDownloadIcon) {
        this.renderAsDownloadIcon = renderAsDownloadIcon;
    }

    @Override
    protected void method_75752(class_332 context, int mouseX, int mouseY, float delta) {
        boolean isHovered = mouseX >= this.method_46426() && mouseY >= this.method_46427() &&
                mouseX < this.method_46426() + this.method_25368() && mouseY < this.method_46427() + this.method_25364();

        if (isHovered && toastManager != null && toastManager.isMouseOverToast(mouseX, mouseY)) {
            isHovered = false;
        }

        int color = !this.field_22763 ? BUTTON_DISABLED_COLOR : isHovered ? BUTTON_HOVER_COLOR : BUTTON_COLOR;

        context.method_25294(this.method_46426(), this.method_46427(), this.method_46426() + this.method_25368(), this.method_46427() + this.method_25364(), color);
        context.method_25294(this.method_46426(), this.method_46427(), this.method_46426() + this.method_25368(), this.method_46427() + 1, 0xFF555555);
        context.method_25294(this.method_46426(), this.method_46427() + this.method_25364() - 1, this.method_46426() + this.method_25368(), this.method_46427() + this.method_25364(), 0xFF555555);
        context.method_25294(this.method_46426(), this.method_46427(), this.method_46426() + 1, this.method_46427() + this.method_25364(), 0xFF555555);
        context.method_25294(this.method_46426() + this.method_25368() - 1, this.method_46427(), this.method_46426() + this.method_25368(), this.method_46427() + this.method_25364(), 0xFF555555);

        class_327 tr = class_310.method_1551().field_1772;
        int textColor = this.field_22763 ? TEXT_COLOR : TEXT_DISABLED_COLOR;
        String messageText = this.method_25369().getString();
        int yOffset = (messageText.equals("⚙") || messageText.equals("🔄")) ? 0 : 1;
        String displayText = renderAsXIcon ? "✕" : renderAsDownloadIcon ? "💾" : messageText;

        context.method_25300(tr, displayText, this.method_46426() + this.method_25368() / 2,
                this.method_46427() + (this.method_25364() - 8) / 2 + yOffset, textColor);
    }
}
