package com.choculaterie.widget;

import org.lwjgl.glfw.GLFW;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;

public class ConfirmPopup implements class_4068, class_364 {
    private static final int POPUP_WIDTH = 400;
    private static final int PADDING = 10;
    private static final int BUTTON_HEIGHT = 20;
    private static final int LINE_HEIGHT = 12;
    private static final int MAX_MESSAGE_HEIGHT = 300;

    private final String title;
    private final Runnable onConfirm;
    private final Runnable onCancel;
    private CustomButton confirmButton;
    private CustomButton cancelButton;
    private boolean wasEnterPressed = false;
    private boolean wasEscapePressed = false;
    private final int x;
    private final int y;
    private final int popupHeight;
    private final List<String> wrappedMessage;
    private final int actualMessageHeight;
    private final int visibleMessageHeight;
    private ScrollBar scrollBar;
    private double scrollOffset = 0;

    public ConfirmPopup(class_437 parent, String title, String message, Runnable onConfirm, Runnable onCancel) {
        this(parent, title, message, onConfirm, onCancel, "Delete");
    }

    public ConfirmPopup(class_437 parent, String title, String message, Runnable onConfirm, Runnable onCancel, String confirmButtonText) {
        this.title = title;
        this.onConfirm = onConfirm;
        this.onCancel = onCancel;

        class_310 client = class_310.method_1551();
        this.wrappedMessage = wrapText(message, POPUP_WIDTH - PADDING * 2, client);

        int screenHeight = client.method_22683().method_4502();
        int screenWidth = client.method_22683().method_4486();
        int verticalMargin = 40;
        int popupChrome = PADDING + LINE_HEIGHT + PADDING + PADDING + BUTTON_HEIGHT + PADDING;
        int maxAvailableMessageHeight = screenHeight - (verticalMargin * 2) - popupChrome;
        int effectiveMaxHeight = Math.min(MAX_MESSAGE_HEIGHT, maxAvailableMessageHeight);

        this.actualMessageHeight = wrappedMessage.size() * LINE_HEIGHT;
        this.visibleMessageHeight = Math.min(actualMessageHeight, effectiveMaxHeight);
        this.popupHeight = PADDING + LINE_HEIGHT + PADDING + visibleMessageHeight + PADDING + BUTTON_HEIGHT + PADDING;

        this.x = (screenWidth - POPUP_WIDTH) / 2;
        this.y = (screenHeight - popupHeight) / 2;

        if (actualMessageHeight > visibleMessageHeight) {
            int messageAreaY = y + PADDING + LINE_HEIGHT + PADDING;
            int scrollBarX = x + POPUP_WIDTH - PADDING - 8;
            this.scrollBar = new ScrollBar(scrollBarX, messageAreaY, visibleMessageHeight);
            this.scrollBar.setScrollData(actualMessageHeight, visibleMessageHeight);
        }

        int buttonY = y + popupHeight - PADDING - BUTTON_HEIGHT;
        int buttonWidth = (POPUP_WIDTH - PADDING * 3) / 2;
        cancelButton = new CustomButton(x + PADDING, buttonY, buttonWidth, BUTTON_HEIGHT, class_2561.method_30163("Cancel"), button -> onCancel.run());
        confirmButton = new CustomButton(x + POPUP_WIDTH - PADDING - buttonWidth, buttonY, buttonWidth, BUTTON_HEIGHT, class_2561.method_30163(confirmButtonText), button -> onConfirm.run());
    }

    private List<String> wrapText(String text, int maxWidth, class_310 client) {
        return com.choculaterie.util.FormatUtils.wrapText(client.field_1772, text, maxWidth);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        class_310 client = class_310.method_1551();
        long windowHandle = client.method_22683() != null ? client.method_22683().method_4490() : 0;

        if (windowHandle != 0) {
            boolean enterPressed = GLFW.glfwGetKey(windowHandle, GLFW.GLFW_KEY_ENTER) == GLFW.GLFW_PRESS ||
                    GLFW.glfwGetKey(windowHandle, GLFW.GLFW_KEY_KP_ENTER) == GLFW.GLFW_PRESS;
            boolean escapePressed = GLFW.glfwGetKey(windowHandle, GLFW.GLFW_KEY_ESCAPE) == GLFW.GLFW_PRESS;
            if (enterPressed && !wasEnterPressed) onConfirm.run();
            if (escapePressed && !wasEscapePressed) onCancel.run();
            wasEnterPressed = enterPressed;
            wasEscapePressed = escapePressed;
        }

        context.method_25294(0, 0, client.method_22683().method_4486(), client.method_22683().method_4502(), 0x80000000);
        context.method_25294(x, y, x + POPUP_WIDTH, y + popupHeight, 0xFF2A2A2A);
        context.method_25294(x, y, x + POPUP_WIDTH, y + 1, 0xFF555555);
        context.method_25294(x, y + popupHeight - 1, x + POPUP_WIDTH, y + popupHeight, 0xFF555555);
        context.method_25294(x, y, x + 1, y + popupHeight, 0xFF555555);
        context.method_25294(x + POPUP_WIDTH - 1, y, x + POPUP_WIDTH, y + popupHeight, 0xFF555555);

        context.method_25300(client.field_1772, title, x + POPUP_WIDTH / 2, y + PADDING, 0xFFFFFFFF);

        int messageAreaY = y + PADDING + LINE_HEIGHT + PADDING;
        context.method_44379(x + PADDING, messageAreaY, x + POPUP_WIDTH - PADDING, messageAreaY + visibleMessageHeight);
        int messageY = messageAreaY - (int) scrollOffset;
        for (String line : wrappedMessage) {
            if (messageY + LINE_HEIGHT >= messageAreaY && messageY < messageAreaY + visibleMessageHeight) {
                context.method_25303(client.field_1772, line, x + PADDING, messageY, 0xFFCCCCCC);
            }
            messageY += LINE_HEIGHT;
        }
        context.method_44380();

        if (scrollBar != null && client.method_22683() != null) {
            scrollBar.setScrollPercentage(scrollOffset / Math.max(1, actualMessageHeight - visibleMessageHeight));
            boolean scrollChanged = scrollBar.updateAndRender(context, mouseX, mouseY, delta, client.method_22683().method_4490());
            if (scrollChanged || scrollBar.isDragging()) {
                double maxScroll = actualMessageHeight - visibleMessageHeight;
                scrollOffset = scrollBar.getScrollPercentage() * maxScroll;
            }
        }

        if (cancelButton != null) cancelButton.method_25394(context, mouseX, mouseY, delta);
        if (confirmButton != null) confirmButton.method_25394(context, mouseX, mouseY, delta);
    }

    public boolean method_25402(net.minecraft.class_11909 click, boolean consumed) {
        if (consumed) {
            return false;
        }
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int button = click.method_74245();

        if (mouseX < x || mouseX > x + POPUP_WIDTH || mouseY < y || mouseY > y + popupHeight) {
            onCancel.run();
            return true;
        }
        if (cancelButton != null && mouseX >= cancelButton.method_46426() && mouseX < cancelButton.method_46426() + cancelButton.method_25368() &&
                mouseY >= cancelButton.method_46427() && mouseY < cancelButton.method_46427() + cancelButton.method_25364()) {
            onCancel.run();
            return true;
        }
        if (confirmButton != null && mouseX >= confirmButton.method_46426() && mouseX < confirmButton.method_46426() + confirmButton.method_25368() &&
                mouseY >= confirmButton.method_46427() && mouseY < confirmButton.method_46427() + confirmButton.method_25364()) {
            onConfirm.run();
            return true;
        }
        return true;
    }

    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (scrollBar != null) {
            int messageAreaY = y + PADDING + LINE_HEIGHT + PADDING;
            if (mouseX >= x && mouseX < x + POPUP_WIDTH && mouseY >= messageAreaY && mouseY < messageAreaY + visibleMessageHeight) {
                double maxScroll = actualMessageHeight - visibleMessageHeight;
                scrollOffset = Math.max(0, Math.min(maxScroll, scrollOffset - verticalAmount * LINE_HEIGHT));
                return true;
            }
        }
        return false;
    }

    @Override
    public void method_25365(boolean focused) {}

    @Override
    public boolean method_25370() {
        return false;
    }
}
