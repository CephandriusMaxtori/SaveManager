package com.choculaterie.widget;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class ToastManager {
    private final List<Toast> toasts = new ArrayList<>();
    private class_310 client;
    private static final int TOP_PADDING = 10;

    public ToastManager(class_310 client) {
        this.client = client;
    }

    public void initClient(class_310 client) {
        this.client = client;
    }

    public void showToast(String message, Toast.Type type) {
        showToast(message, type, false, null, null);
    }

    public void showToast(String message, Toast.Type type, boolean hasCopyButton, String copyText) {
        showToast(message, type, hasCopyButton, copyText, null);
    }

    public void showToast(String message, Toast.Type type, boolean hasCopyButton, String copyText, String hintText) {
        if (client.method_22683() == null) return;
        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();
        int yPosition = TOP_PADDING;
        for (Toast toast : toasts) {
            yPosition += toast.getHeight();
        }
        if (yPosition + 70 > screenHeight) {
            if (!toasts.isEmpty()) {
                toasts.remove(0);
                yPosition = TOP_PADDING;
                for (Toast toast : toasts) {
                    yPosition += toast.getHeight();
                }
            }
        }
        toasts.add(new Toast(message, type, screenWidth, yPosition, hasCopyButton, copyText, hintText));
    }

    public void showSuccess(String message) {
        showToast(message, Toast.Type.SUCCESS);
    }

    public void showError(String message) {
        showToast(message, Toast.Type.ERROR);
    }

    public void showError(String message, String hintText) {
        showToast(message, Toast.Type.ERROR, false, null, hintText);
    }

    public void showError(String message, String fullErrorText, String hintText) {
        showToast(message, Toast.Type.ERROR, true, fullErrorText, hintText);
    }

    public void showInfo(String message) {
        showToast(message, Toast.Type.INFO);
    }

    public void showWarning(String message) {
        showToast(message, Toast.Type.WARNING);
    }

    public void render(class_332 context, float delta, int mouseX, int mouseY) {
        if (toasts.isEmpty()) return;
        Toast.updateMousePosition(mouseX, mouseY);
        Iterator<Toast> iterator = toasts.iterator();
        boolean toastRemoved = false;
        while (iterator.hasNext()) {
            Toast toast = iterator.next();
            toast.setHovered(toast.isHovering(mouseX, mouseY));
            boolean shouldRemove = toast.render(context, client.field_1772);
            if (shouldRemove) {
                iterator.remove();
                toastRemoved = true;
            }
        }
        if (toastRemoved && !toasts.isEmpty()) {
            int newY = TOP_PADDING;
            for (Toast toast : toasts) {
                toast.setTargetYPosition(newY);
                newY += toast.getHeight();
            }
        }
    }

    public void clear() {
        toasts.clear();
    }

    public boolean hasToasts() {
        return !toasts.isEmpty();
    }

    public boolean isMouseOverToast(double mouseX, double mouseY) {
        for (Toast toast : toasts) {
            if (toast.isHovering(mouseX, mouseY)) {
                return true;
            }
        }
        return false;
    }

    public boolean mouseClicked(net.minecraft.class_11909 click, boolean consumed) {
        if (consumed) {
            return false;
        }
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();

        for (Toast toast : toasts) {
            if (toast.isCloseButtonClicked(mouseX, mouseY)) {
                toast.dismiss();
                return true;
            }
            if (toast.isCopyButtonClicked(mouseX, mouseY)) {
                String textToCopy = toast.getCopyText();
                if (client.field_1774 != null) {
                    client.field_1774.method_1455(textToCopy);
                    showSuccess("Error copied to clipboard!");
                    return true;
                }
            }
        }
        return false;
    }
}
