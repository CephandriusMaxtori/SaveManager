package com.choculaterie.mixin;

import com.choculaterie.gui.SaveManagerScreen;
import com.choculaterie.widget.CustomButton;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import net.minecraft.class_526;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_526.class)
public abstract class SinglePlayerScreenMixin extends class_437 {
    protected SinglePlayerScreenMixin(class_2561 title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"), remap = false)
    private void savemanager$init(CallbackInfo ci) {
        method_37063(new CustomButton(6, 6, 20, 20, class_2561.method_43470("☁"),
                b -> this.field_22787.method_1507(new SaveManagerScreen((class_437)(Object)this))));
    }
}
