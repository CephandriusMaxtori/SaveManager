package com.choculaterie.gui;

import com.choculaterie.network.NetworkManager;
import com.choculaterie.util.ConfigManager;
import com.choculaterie.util.ScreenUtils;
import com.choculaterie.widget.CustomButton;
import com.choculaterie.widget.ToastManager;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_407;
import net.minecraft.class_437;
import net.minecraft.class_526;

public class AccountLinkingScreen extends class_437 {
    private final class_437 parent;
    private final NetworkManager networkManager = new NetworkManager();
    private final ToastManager toastManager;

    private String currentFlowId = null;
    private String pendingLinkCode = null;
    private String isLinkingStatus = "";
    private boolean isLinking = false;
    private String pendingAuthUrl = null;
    private ScheduledExecutorService pollExecutor = null;
    private CustomButton linkBtn = null;
    private CustomButton copyUrlBtn = null;

    public AccountLinkingScreen(class_437 parent) {
        super(class_2561.method_43470("Link Your Account"));
        this.parent = parent;
        this.toastManager = new ToastManager(null);
    }

    @Override
    protected void method_25426() {
        toastManager.initClient(field_22787);

        int btnSize = 20, margin = 6;
        method_37063(new CustomButton(margin, margin, btnSize, btnSize, class_2561.method_43470("←"), b -> goBack()));

        String apiKey = ConfigManager.loadApiKey();
        boolean hasKey = apiKey != null && !apiKey.isBlank();

        int cx = this.field_22789 / 2, btnW = 100;
        int btnY = this.field_22790 / 2 - 10;
        
        linkBtn = new CustomButton(cx - btnW / 2, btnY, btnW, 20,
                class_2561.method_43470(hasKey ? "Reset" : "Link Account"),
                b -> handleLinkOrReset(hasKey));
        method_37063(linkBtn);

        copyUrlBtn = new CustomButton(cx - btnW / 2, btnY, btnW, 20,
                class_2561.method_43470("Copy URL"), b -> copyAuthUrl());
        copyUrlBtn.field_22764 = false;
        method_37063(copyUrlBtn);

        if (hasKey) networkManager.setApiKey(apiKey);
    }

    private void handleLinkOrReset(boolean hasKey) {
        if (hasKey) {
            networkManager.setApiKey(null);
            ConfigManager.clearApiKey();
            field_22787.method_1507(new AccountLinkingScreen(parent));
        } else {
            startOAuthFlow();
        }
    }

    private void startOAuthFlow() {
        if (isLinking) return;
        isLinking = true;
        isLinkingStatus = "Initiating...";

        networkManager.initiateOAuthFlow("SaveManager Mod").whenComplete((json, err) -> {
            if (err != null) {
                runOnClient(mc -> { isLinking = false; isLinkingStatus = ""; });
                return;
            }
            try {
                currentFlowId = json.has("flowId") ? json.get("flowId").getAsString() : null;
                int expiresIn = json.has("expiresInSeconds") ? json.get("expiresInSeconds").getAsInt() : 300;
                
                if (currentFlowId == null) {
                    runOnClient(mc -> { isLinking = false; isLinkingStatus = ""; });
                    return;
                }

                String authUrl = networkManager.getOAuthAuthorizeUrl(currentFlowId);
                
                runOnClient(mc -> {
                    pendingAuthUrl = authUrl;
                    if (linkBtn != null) linkBtn.field_22764 = false;
                    if (copyUrlBtn != null) copyUrlBtn.field_22764 = true;
                    isLinkingStatus = "Waiting for approval...";

                    // Use the standard Minecraft Link Opening Screen
                    mc.method_1507(new class_407(confirmed -> {
                        if (confirmed) {
                            class_156.method_668().method_670(authUrl);
                        }
                        // Return to this screen regardless of choice to continue polling
                        mc.method_1507(this);
                    }, authUrl, true));
                });

                startPolling(currentFlowId, expiresIn);
            } catch (Exception e) {
                runOnClient(mc -> { isLinking = false; isLinkingStatus = ""; });
            }
        });
    }

    private void startPolling(String flowId, int timeoutSeconds) {
        stopPolling();
        pollExecutor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "SaveManager-OAuth-Poll");
            t.setDaemon(true);
            return t;
        });

        final int[] attempts = {0};
        final int maxAttempts = timeoutSeconds / 2;

        pollExecutor.scheduleAtFixedRate(() -> {
            if (++attempts[0] >= maxAttempts) {
                runOnClient(mc -> { stopPolling(); isLinking = false; isLinkingStatus = ""; });
                return;
            }
            networkManager.getOAuthFlowStatus(flowId).whenComplete((json, err) -> {
                if (err != null) return;
                runOnClient(mc -> handlePollResponse(json, mc));
            });
        }, 0, 2, TimeUnit.SECONDS);
    }

    private void handlePollResponse(com.google.gson.JsonObject json, class_310 mc) {
        String status = json.has("status") ? json.get("status").getAsString() : "pending";

        switch (status) {
            case "expired" -> { stopPolling(); isLinking = false; isLinkingStatus = ""; }
            case "cancelled" -> {
                stopPolling();
                isLinking = false;
                isLinkingStatus = "§cCancelled";
                CompletableFuture.delayedExecutor(3, TimeUnit.SECONDS).execute(() -> runOnClient(m -> isLinkingStatus = ""));
            }
            case "pending" -> isLinkingStatus = "Waiting for approval...";
            case "completed" -> handleCompleted(json, mc);
        }
    }

    private void handleCompleted(com.google.gson.JsonObject json, class_310 mc) {
        String saveKey = json.has("saveKey") ? json.get("saveKey").getAsString() : null;
        if (saveKey == null) return;

        boolean isMinecraftLinked = json.has("isMinecraftLinked") && json.get("isMinecraftLinked").getAsBoolean();
        boolean linkingComplete = json.has("minecraftLinkingComplete") && json.get("minecraftLinkingComplete").getAsBoolean();
        String linkCode = json.has("linkCode") && !json.get("linkCode").isJsonNull() ? json.get("linkCode").getAsString() : null;

        if (isMinecraftLinked) {
            stopPolling();
            completeLinking(saveKey);
            return;
        }
        if (linkingComplete) {
            stopPolling();
            if (mc.method_1562() != null) {
                mc.method_1562().method_48296().method_10747(class_2561.method_43470("Linking complete"));
            }
            CompletableFuture.delayedExecutor(1, TimeUnit.SECONDS).execute(() -> runOnClient(m -> completeLinking(saveKey)));
            return;
        }
        if (linkCode != null && !linkCode.equals(pendingLinkCode)) {
            pendingLinkCode = linkCode;
            isLinkingStatus = "Linking MC account...";
            autoJoinServerAndLink(linkCode);
        }
    }

    private void autoJoinServerAndLink(String linkCode) {
        isLinkingStatus = "Joining server...";
        runOnClient(mc -> {
            try {
                var serverAddress = net.minecraft.class_639.method_2950("mc.choculaterie.com");
                var serverInfo = new net.minecraft.class_642(
                        "Choculaterie", "mc.choculaterie.com", net.minecraft.class_642.class_8678.field_45611);

                net.minecraft.class_412.method_36877(this, mc, serverAddress, serverInfo, false, null);
                scheduleLinkCommand(mc, linkCode, 6);
            } catch (Exception e) {
                isLinking = false;
                isLinkingStatus = "";
            }
        });
    }

    private void scheduleLinkCommand(class_310 mc, String linkCode, int delaySeconds) {
        CompletableFuture.delayedExecutor(delaySeconds, TimeUnit.SECONDS).execute(() -> runOnClient(m -> {
            if (m.field_1724 != null && m.field_1724.field_3944 != null) {
                isLinkingStatus = "Sending link command...";
                m.field_1724.field_3944.method_45730("link " + linkCode);
            } else if (delaySeconds == 6) {
                scheduleLinkCommand(m, linkCode, 3);
            }
        }));
    }

    private void completeLinking(String saveKey) {
        stopPolling();
        isLinking = false;
        isLinkingStatus = "";
        pendingLinkCode = null;
        currentFlowId = null;

        networkManager.setApiKey(saveKey);
        ConfigManager.saveApiKey(saveKey);

        runOnClient(mc -> {
            SaveManagerScreen screen = (parent instanceof SaveManagerScreen sms) ? sms : new SaveManagerScreen(parent);
            mc.method_1507(screen);
            screen.refresh();
        });
    }

    private void goBack() {
        stopPolling();
        String apiKey = ConfigManager.loadApiKey();
        runOnClient(mc -> {
            if (parent instanceof SaveManagerScreen sms && (apiKey == null || apiKey.isBlank())) {
                mc.method_1507(new class_526(ScreenUtils.resolveRootParent(parent)));
            } else {
                mc.method_1507(parent);
            }
        });
    }

    private void stopPolling() {
        if (pollExecutor != null && !pollExecutor.isShutdown()) {
            pollExecutor.shutdownNow();
            pollExecutor = null;
        }
    }

    private void copyAuthUrl() {
        if (pendingAuthUrl != null && field_22787 != null && field_22787.field_1774 != null) {
            field_22787.field_1774.method_1455(pendingAuthUrl);
            toastManager.showSuccess("URL copied! Paste it in your browser.");
        }
    }

    private void runOnClient(java.util.function.Consumer<class_310> action) {
        class_310 mc = class_310.method_1551();
        if (mc != null) mc.execute(() -> action.accept(mc));
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        int cx = this.field_22789 / 2;
        int btnY = this.field_22790 / 2 - 10;

        context.method_27534(field_22793, field_22785, cx, 10, 0xFFFFFFFF);

        String apiKey = ConfigManager.loadApiKey();
        boolean hasKey = apiKey != null && !apiKey.isBlank();

        if (hasKey && !isLinking) {
            context.method_25300(field_22793, "§aAccount linked ✓", cx, btnY - 20, 0xFFFFFFFF);
            context.method_25300(field_22793, "Reset to unlink and connect a different account.", cx, btnY + 30, 0xFF888888);
        } else if (!isLinking) {
            int stepY = btnY + 32;
            context.method_25300(field_22793, "How it works:", cx, stepY, 0xFF999999);
            context.method_25300(field_22793, "1. A browser window will open. Sign in and click Approve.", cx, stepY + 16, 0xFFCCCCCC);
            context.method_25300(field_22793, "2. The game will briefly join a server to verify your Minecraft account.", cx, stepY + 28, 0xFFCCCCCC);
            context.method_25300(field_22793, "3. Once verified, you're ready to sync your saves!", cx, stepY + 40, 0xFFCCCCCC);
        } else {
            if (!isLinkingStatus.isEmpty()) {
                context.method_25300(field_22793, isLinkingStatus, cx, btnY - 20, 0xFF88FF88);
            }
            if (pendingAuthUrl != null) {
                context.method_25300(field_22793, "Browser didn't open? Copy the URL and paste it manually.", cx, btnY + 30, 0xFF888888);
            }
        }
        toastManager.render(context, delta, mouseX, mouseY);
    }

    @Override
    public void method_25432() { stopPolling(); }

    @Override
    public boolean method_25422() { return true; }

    @Override
    public void method_25419() { goBack(); }
}