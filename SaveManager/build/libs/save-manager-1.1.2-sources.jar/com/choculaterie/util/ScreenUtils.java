package com.choculaterie.util;

import java.lang.reflect.Field;
import net.minecraft.class_437;
import net.minecraft.class_526;

public final class ScreenUtils {
    private ScreenUtils() {}

    public static class_437 resolveRootParent(class_437 parent) {
        class_437 p = parent;
        int guard = 0;
        while (p instanceof class_526 && guard++ < 8) {
            try {
                Field f = class_526.class.getDeclaredField("parent");
                f.setAccessible(true);
                class_437 next = (class_437) f.get(p);
                if (next == null || next == p) break;
                p = next;
            } catch (Throwable ignored) {
                break;
            }
        }
        return p;
    }
}
